

import baycomp as bc
import numpy as np
import matplotlib.pyplot as plt
from baycomp import two_on_single

from data import get_data
if __name__ == '__main__':


    # datas = ["anneal","audiology","cleeland-14","cmc","contact-lenses","credit","ecoli","eucalyptus","german-credit","glass","grub-damage","haberman","hayes-roth","hepatitis","hungarian-14","hypothyroid","ionosphere","iris","kr-s-kp","labor","lier-disorders","lymphography","monks","monks1","monks3","mushroom","nursery","optdigits","owel","page-blocks","pasture-production","pendigits","pima-diabetes","postoperatie","primary-tumor","segment","solar-flare-C","solar-flare-X","solar-flare-m","sonar","soybean","spambase","spect-reordered","splice","squash-stored","0.000","squash-unstored","tae","waveform","white-clover","wine","wisconsin-breast-cancer","yeast","zoo"]
    # names = ("nbc", "aode")
    #
    #
    # # single data
    # data_nbc = get_data("nbc","ecoli")
    # data_aode = get_data("aode","ecoli")
    #
    # ctT = bc.CorrelatedTTest(data_nbc, data_aode, rope=0.01, names=names)
    # print(ctT.probs())
    # ctT.plot()
    # plt.title("CorrelatedTTest")
    # plt.show()

    # #multiple data one-dimension
    # data_nbc = get_data("nbc", aggregate=True)
    # data_aode = get_data("aode", aggregate=True)
    #



    T1T5_500 = np.array([ 0.75336, 0.79385, 0.64004, 0.62851, 0.75019, 0.80813, 0.74433, 0.80335])
    T1T5_1500 = np.array([0.79073, 0.76489, 0.66309, 0.64565, 0.74482, 0.79619, 0.75246, 0.77086])
    T1T5_1000 = np.array([0.8203, 0.73338, 0.70922, 0.58107, 0.71025, 0.87761, 0.79125, 0.72255])
    T1T5_2000 = np.array([0.81499, 0.78228, 0.65534, 0.52541, 0.73074, 0.83445, 0.86284, 0.76615])

    T5_500 = np.array([0.81601, 0.74953, 0.64122, 0.61123, 0.7641, 0.77047, 0.74317, 0.77705])
    T5_1000 = np.array([0.76768,0.70816,0.57425,0.6214,0.76319,0.80433,0.68427,0.78404])
    T5_1500 = np.array([0.76673, 0.78212, 0.61297, 0.58316, 0.74072, 0.77106, 0.78272, 0.8401])
    T5_2000 = np.array([0.75689,0.76576,0.66392,0.5912,0.77032,0.81609,0.73845,0.82553])

    Coop_T5_2000 = np.array([0.78281, 0.74084, 0.68198, 0.61015, 0.74764, 0.77492, 0.81336, 0.89184])

    FPT_2D = np.array([0.713, 0.714, 0.378, 0.329, 0.683, 0.667, 0.649, 0.737])
    O3Q = np.array([0.69, 0.67, 0.17, 0.32, 0.6, 0.5, 0.51, 0.67])
    Midas = np.array([0.7838,0.66,0.61,0.5,0.6466,0.8338,0.7314,0.7759])
    COSMOsar3D = np.array([0.62, 0.61, 0.13, 0.43, 0.58, 0.63, 0.59, 0.66])

    conf1 = "Coop_T5_2000"
    ref = Coop_T5_2000

    conf2 = "T5_2000"

    srT = bc.SignedRankTest(Coop_T5_2000, T5_2000, rope=0.01, nsamples=500000,)
    print(srT.probs())
    # srT.plot_simplex(names=(conf1, conf2))

    srT.plot(names=(conf1, conf2))
    plt.title("SignedRankTest")
    plt.savefig("SignedRankTest_{}_{}.png".format(conf1, conf2))
    plt.show()
    #
    # conf2 = "2D-FPT"
    # srT = bc.SignedRankTest(ref, FPT_2D, rope=0.01, nsamples=500000)
    # print(srT.probs())
    # srT.plot(names=(conf1, conf2)).savefig("{}_{}.png".format(conf1, conf2))
    #
    # conf2 = "COSMOsar3D"
    # srT = bc.SignedRankTest(ref, COSMOsar3D, rope=0.01, nsamples=500000)
    # print(srT.probs())
    # srT.plot(names=(conf1, conf2)).savefig("{}_{}.png".format(conf1, conf2))
    # plt.show()

    #
    # sT = bc.SignTest(data_nbc, data_aode, rope=0.01)
    # print(sT.probs())
    # sT.plot_simplex(names)
    # plt.title("SignedTest")
    # plt.show()
    #
    # # multiple data two-dimension
    # data_nbc = get_data("nbc")
    # data_aode = get_data("aode")
    #
    # hT = bc.HierarchicalTest(data_nbc, data_aode, rope=0.01)
    # print(hT.probs())
    # hT.plot_simplex(names)
    # plt.title("HierarchicalTest")
    # plt.show()
